$('#signup').click(function() {
 	$('.pinkbox').css('transform', 'translateX(80%)');
 	$('.signup').css("display", "block");
 	$('.signin').css("display", "none");
 });
 $('#signin').click(function() {
 	$('.pinkbox').css('transform', 'translateX(0%)');
 	$('.signin').css("display", "block");
 	$('.signup').css("display", "none");
 });

 function fun() {
 	var x = document.getElementById("mz");
 	var j = document.getElementById("yx");
 	var y = document.getElementById("mm");
 	var z = document.getElementById("yz");
 	if (x.value == '') {
 		alert('用户名不能为空');
 	} else if (j.value == '') {
 		alert('邮箱不能为空');
 	} else if (y.value == '') {
 		alert('密码不能为空');
 	} else if (z.value != y.value) {
 		alert('两次密码不相符');
 	} else if (y.value == z.value) {
 		alert('注册成功');
 	}
 }

 function knock() {
 	var h = document.getElementById("mz1");
 	var f = document.getElementById("mm1");
 	if (h.value == '') {
 		alert('请输入用户名');
 	} else if (f.value == '') {
 		alert('请输入密码');
 	}else{
			alert('登录成功');
			location.href="index.html"
		}
}
